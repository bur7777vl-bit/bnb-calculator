# BNB Flow Lens Android

Native Android companion for BNBUSDT perpetual flow monitoring.

- Public Binance Futures data only; no API keys, login, orders or trading permissions.
- Portrait layout tuned for a 1080x2400-class phone such as POCO X3 Pro.
- M15 / H1 / H4 context.
- DOM aggregation steps: 0.1 / 0.5 / 1 / 2 / 5 / 10 USDT.
- 3 / 6 / 9 / 12 visible levels per side.
- Top-3 walls highlighted; persistence counter after several refreshes.
- Taker buy share, OI and OI delta, global long/short ratio.
- ~1.5 second refresh.

Build with Android SDK 35 and Gradle 8.10.2:

    gradle :app:assembleDebug

APK output:

    app/build/outputs/apk/debug/app-debug.apk
