package com.bnbflowlens.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final DecimalFormat p2 = new DecimalFormat("0.00");
    private final DecimalFormat q1 = new DecimalFormat("0.0");

    private LinearLayout root, asksBox, bidsBox;
    private TextView priceText, changeText, oiText, oiDeltaText, takerText, ratioText, statusText, domBiasText;
    private String tf = "15m";
    private double step = 1.0;
    private int levels = 9;
    private boolean running = true;
    private final Map<String,Integer> holdCounts = new HashMap<>();

    private final int BG = Color.rgb(10,13,18);
    private final int CARD = Color.rgb(18,23,31);
    private final int LINE = Color.rgb(41,49,62);
    private final int TEXT = Color.rgb(232,236,242);
    private final int MUTED = Color.rgb(139,151,169);
    private final int GREEN = Color.rgb(58,201,128);
    private final int RED = Color.rgb(242,92,110);
    private final int BLUE = Color.rgb(86,154,255);
    private final int AMBER = Color.rgb(247,184,67);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        refresh();
    }

    @Override protected void onDestroy() {
        running = false;
        io.shutdownNow();
        super.onDestroy();
    }

    private TextView tv(String s, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(color);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(dp(8),dp(7),dp(8),dp(7));
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12),dp(10),dp(12),dp(18)); scroll.addView(root);

        LinearLayout head = new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = tv("BNB FLOW LENS",20,TEXT,true);
        TextView tag = tv("PERP",11,AMBER,true);
        head.addView(title,new LinearLayout.LayoutParams(0,dp(52),1)); head.addView(tag);
        root.addView(head);

        LinearLayout priceCard = card();
        priceText = tv("—",32,TEXT,true); changeText = tv("BNBUSDT",13,MUTED,true);
        priceCard.addView(priceText); priceCard.addView(changeText); root.addView(priceCard);

        root.addView(section("ТАЙМФРЕЙМ"));
        LinearLayout tfs = new LinearLayout(this); tfs.setGravity(Gravity.CENTER);
        String[] names={"M15","H1","H4"}; String[] vals={"15m","1h","4h"};
        for(int i=0;i<3;i++){ Button b=smallButton(names[i]); final String v=vals[i]; b.setOnClickListener(x->{tf=v; refresh();}); tfs.addView(b,new LinearLayout.LayoutParams(0,dp(46),1)); }
        root.addView(tfs);

        LinearLayout metrics = new LinearLayout(this); metrics.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout left=card(), right=card();
        oiText=tv("OI —",16,TEXT,true); oiDeltaText=tv("Δ —",12,MUTED,false); left.addView(oiText); left.addView(oiDeltaText);
        takerText=tv("Taker —",16,TEXT,true); ratioText=tv("L/S —",12,MUTED,false); right.addView(takerText); right.addView(ratioText);
        metrics.addView(left,new LinearLayout.LayoutParams(0,-2,1)); metrics.addView(right,new LinearLayout.LayoutParams(0,-2,1)); root.addView(metrics);

        root.addView(section("DOM · СТАКАН"));
        LinearLayout selectors = new LinearLayout(this); selectors.setGravity(Gravity.CENTER_VERTICAL);
        Spinner stepSpin=new Spinner(this); String[] steps={"0.1","0.5","1","2","5","10"}; stepSpin.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,steps)); stepSpin.setSelection(2);
        stepSpin.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){step=Double.parseDouble(steps[pos]); refresh();}});
        Spinner levelSpin=new Spinner(this); String[] lev={"3","6","9","12"}; levelSpin.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,lev)); levelSpin.setSelection(2);
        levelSpin.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){levels=Integer.parseInt(lev[pos]); refresh();}});
        selectors.addView(tv("Шаг",12,MUTED,true)); selectors.addView(stepSpin,new LinearLayout.LayoutParams(0,dp(48),1)); selectors.addView(tv("Уровни",12,MUTED,true)); selectors.addView(levelSpin,new LinearLayout.LayoutParams(0,dp(48),1)); root.addView(selectors);

        LinearLayout domCard=card(); asksBox=new LinearLayout(this); asksBox.setOrientation(LinearLayout.VERTICAL); bidsBox=new LinearLayout(this); bidsBox.setOrientation(LinearLayout.VERTICAL);
        domBiasText=tv("DOM —",13,MUTED,true);
        domCard.addView(tv("ASKS",12,RED,true)); domCard.addView(asksBox); domCard.addView(domBiasText); domCard.addView(bidsBox); domCard.addView(tv("BIDS",12,GREEN,true)); root.addView(domCard);
        statusText=tv("Подключение к Binance Futures…",12,MUTED,false); root.addView(statusText);
        root.addView(tv("Публичные данные Binance Futures · без API-ключей · обновление ~1.5 сек",11,MUTED,false));
        setContentView(scroll);
    }

    private LinearLayout card(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(8),dp(8),dp(8),dp(8)); l.setBackgroundColor(CARD); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(5),0,dp(5)); l.setLayoutParams(p); return l; }
    private TextView section(String s){ TextView v=tv(s,12,MUTED,true); v.setPadding(dp(4),dp(13),0,dp(3)); return v; }
    private Button smallButton(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(TEXT); b.setTextSize(13); b.setAllCaps(false); b.setBackgroundColor(CARD); return b; }
    private int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }

    private void refresh(){ if(!running)return; io.execute(()->{ try { Snapshot s=load(); ui.post(()->render(s)); } catch(Exception e){ ui.post(()->statusText.setText("Ошибка сети: "+e.getClass().getSimpleName())); } finally { if(running) ui.postDelayed(this::refresh,1500); } }); }

    private Snapshot load() throws Exception {
        Snapshot s=new Snapshot();
        JSONObject ticker=new JSONObject(get("https://fapi.binance.com/fapi/v1/ticker/24hr?symbol=BNBUSDT"));
        s.price=ticker.getDouble("lastPrice"); s.change=ticker.getDouble("priceChangePercent");
        JSONObject oi=new JSONObject(get("https://fapi.binance.com/fapi/v1/openInterest?symbol=BNBUSDT")); s.oi=oi.getDouble("openInterest");
        JSONArray oih=new JSONArray(get("https://fapi.binance.com/futures/data/openInterestHist?symbol=BNBUSDT&period="+tf+"&limit=2"));
        if(oih.length()>=2){ double a=oih.getJSONObject(0).getDouble("sumOpenInterest"); double b=oih.getJSONObject(1).getDouble("sumOpenInterest"); s.oiDelta=a==0?0:(b-a)/a*100.0; }
        JSONArray tak=new JSONArray(get("https://fapi.binance.com/futures/data/takerlongshortRatio?symbol=BNBUSDT&period="+tf+"&limit=1"));
        if(tak.length()>0){ JSONObject t=tak.getJSONObject(0); s.buyVol=t.getDouble("buyVol"); s.sellVol=t.getDouble("sellVol"); }
        JSONArray ls=new JSONArray(get("https://fapi.binance.com/futures/data/globalLongShortAccountRatio?symbol=BNBUSDT&period="+tf+"&limit=1")); if(ls.length()>0) s.ls=ls.getJSONObject(0).getDouble("longShortRatio");
        JSONObject depth=new JSONObject(get("https://fapi.binance.com/fapi/v1/depth?symbol=BNBUSDT&limit=1000"));
        s.asks=aggregate(depth.getJSONArray("asks"),true,s.price); s.bids=aggregate(depth.getJSONArray("bids"),false,s.price);
        return s;
    }

    private List<Level> aggregate(JSONArray arr, boolean ask, double price) throws Exception {
        TreeMap<Double,Double> map=new TreeMap<>();
        for(int i=0;i<arr.length();i++){ JSONArray r=arr.getJSONArray(i); double p=Double.parseDouble(r.getString(0)), q=Double.parseDouble(r.getString(1)); double bucket=ask?Math.ceil(p/step)*step:Math.floor(p/step)*step; map.put(bucket,map.getOrDefault(bucket,0.0)+q); }
        List<Level> out=new ArrayList<>(); NavigableMap<Double,Double> nav=ask?map.tailMap(price,true):map.headMap(price,true).descendingMap();
        int n=0; for(Map.Entry<Double,Double> e:nav.entrySet()){ if(n++>=levels)break; out.add(new Level(e.getKey(),e.getValue())); }
        return out;
    }

    private void render(Snapshot s){
        priceText.setText(p2.format(s.price)); priceText.setTextColor(s.change>=0?GREEN:RED);
        changeText.setText("BNBUSDT PERP   "+(s.change>=0?"+":"")+p2.format(s.change)+"%   ·   "+tf.toUpperCase(Locale.US));
        oiText.setText("OI  "+compact(s.oi)+" BNB"); oiDeltaText.setText("Δ "+(s.oiDelta>=0?"+":"")+p2.format(s.oiDelta)+"%"); oiDeltaText.setTextColor(s.oiDelta>=0?GREEN:RED);
        double total=s.buyVol+s.sellVol, buyPct=total==0?0:s.buyVol/total*100; takerText.setText("Taker  "+p2.format(buyPct)+"% BUY"); takerText.setTextColor(buyPct>=50?GREEN:RED); ratioText.setText("Long/Short  "+p2.format(s.ls));
        double bq=sum(s.bids), aq=sum(s.asks), dom=aq+bq==0?50:bq/(aq+bq)*100; domBiasText.setText("DOM  bids "+p2.format(dom)+"%   ·   asks "+p2.format(100-dom)+"%"); domBiasText.setTextColor(dom>=50?GREEN:RED);
        renderLevels(asksBox,s.asks,true); renderLevels(bidsBox,s.bids,false); statusText.setText("LIVE · шаг "+step+" USDT · удержание 1.5 сек");
    }

    private void renderLevels(LinearLayout box,List<Level> ls,boolean ask){ box.removeAllViews(); List<Level> rank=new ArrayList<>(ls); rank.sort((a,b)->Double.compare(b.qty,a.qty)); Set<Double> top=new HashSet<>(); for(int i=0;i<Math.min(3,rank.size());i++) top.add(rank.get(i).price);
        if(ask){ List<Level> rev=new ArrayList<>(ls); Collections.reverse(rev); ls=rev; }
        Set<String> now=new HashSet<>(); for(Level l:ls){ String k=(ask?"A":"B")+":"+p2.format(l.price); now.add(k); int h=holdCounts.getOrDefault(k,0)+1; holdCounts.put(k,h); LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); if(top.contains(l.price)) row.setBackgroundColor(ask?Color.rgb(61,25,32):Color.rgb(20,56,42)); TextView p=tv(p2.format(l.price),14,ask?RED:GREEN,true); TextView q=tv(q1.format(l.qty)+" BNB"+(h>=3?"  ×"+h:""),13,TEXT,top.contains(l.price)); row.addView(p,new LinearLayout.LayoutParams(0,dp(38),1)); row.addView(q,new LinearLayout.LayoutParams(0,dp(38),1)); box.addView(row); View line=new View(this); line.setBackgroundColor(LINE); box.addView(line,new LinearLayout.LayoutParams(-1,1)); }
        holdCounts.keySet().removeIf(k->k.startsWith(ask?"A:":"B:")&&!now.contains(k)); }

    private double sum(List<Level> ls){ double x=0; for(Level l:ls)x+=l.qty; return x; }
    private String compact(double v){ if(v>=1_000_000)return p2.format(v/1_000_000)+"M"; if(v>=1000)return p2.format(v/1000)+"K"; return p2.format(v); }
    private String get(String u) throws Exception { HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection(); c.setConnectTimeout(7000); c.setReadTimeout(7000); c.setRequestProperty("User-Agent","BNB-Flow-Lens-Android/1.0"); int code=c.getResponseCode(); if(code!=200)throw new RuntimeException("HTTP "+code); BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8)); StringBuilder b=new StringBuilder(); String line; while((line=r.readLine())!=null)b.append(line); r.close(); c.disconnect(); return b.toString(); }

    static class Level { double price,qty; Level(double p,double q){price=p;qty=q;} }
    static class Snapshot { double price,change,oi,oiDelta,buyVol,sellVol,ls; List<Level> asks,bids; }
}
